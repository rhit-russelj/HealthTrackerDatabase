package sodabase.services;

public class EncryptionService {
	
	public String getEncryptionPassword() {
		//TODO: Task 8
		return "c3OxKJo5CR";
	}

}

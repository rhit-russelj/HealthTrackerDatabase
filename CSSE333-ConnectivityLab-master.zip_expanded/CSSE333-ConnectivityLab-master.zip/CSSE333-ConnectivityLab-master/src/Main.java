import sodabase.ui.ApplicationRunner;

public class Main {

	public static void main(String[] args) {
		ApplicationRunner appRunner = new ApplicationRunner();
		appRunner.runApplication(args);
	}

}
